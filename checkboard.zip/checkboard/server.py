from flask import Flask, render_template
app= Flask(__name__)


@app.route('/')
def index():
    return render_template("index.html", phrase="***Checkerboard***", times=8)


@app.route('/4')
def index2():
    return render_template("index2.html", phrase="***Checkerboard***", times=8)


@app.route('/last/<int:num1>/<int:num2>')
def index3(num1,num2):
    num1=num1
    num2=num2

    return render_template("index3.html", phrase="***Checkerboard***", num1=num1,num2=num2)








if __name__ =="__main__":
    app.run(debug=True)